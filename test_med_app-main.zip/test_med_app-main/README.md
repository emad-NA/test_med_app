# test_med_app
Medical Appointment App
A user-friendly app for scheduling and managing medical appointments.

Features
Book, and cancel appointments.
Review doctors after appointments.

Tech Stack
React, TBD.

Setup
TBD.
